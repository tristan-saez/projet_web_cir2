





INSERT INTO `profile` (`mail`, `first_name`, `last_name`, `password`, `picture`, `played_matches`, `app_note`, `birthdate`, `physical_shape`, `insee`) VALUES ('david.poulet@gmail.com', 'David', 'Poulet', '$argon2i$v=19$m=65536,t=4,p=1$YWliYTZTdDRkR3RzZXR3cQ$T9y945XVReRX+j+nGkxRW/HLgh3nKWiThWXCsB6Rc+4', '/assets/profilpicture/pp_1.png', '0', '4', '2018-10-03', '3', '29019');
INSERT INTO `profile` (`mail`, `first_name`, `last_name`, `password`, `picture`, `played_matches`, `app_note`, `birthdate`, `physical_shape`, `insee`) VALUES ('thierry.golo@gmail.com', 'Thierry', 'Golo', '$argon2i$v=19$m=65536,t=4,p=1$YWliYTZTdDRkR3RzZXR3cQ$T9y945XVReRX+j+nGkxRW/HLgh3nKWiThWXCsB6Rc+4', '/assets/profilpicture/pp_15.png', '0', '5', '1942-02-01', '5', '30068');
INSERT INTO `profile` (`mail`, `first_name`, `last_name`, `password`, `picture`, `played_matches`, `app_note`, `birthdate`, `physical_shape`, `insee`) VALUES ('regis.lebail@gmail.com', 'Regis', 'Lebail', '$argon2i$v=19$m=65536,t=4,p=1$YWliYTZTdDRkR3RzZXR3cQ$T9y945XVReRX+j+nGkxRW/HLgh3nKWiThWXCsB6Rc+4', '/assets/profilpicture/pp_13.png', '0', '2', '1999-06-06', '2', '31278');

