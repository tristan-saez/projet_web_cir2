<?php
    /**
    * @Author: Tristan Saëz & Antonin Soquet
    * @Company: ISEN Yncréa Ouest
    * @Email: tristan.saez@isen-ouest.yncrea.fr - antonin.soquet@isen-ouest.yncrea.fr
    */

    // Database constants.
    define('DB_USER', 'default_user');
    define('DB_PASSWORD', 'p@ss_conn3ction');
    define('DB_NAME', 'projet');
    define('DB_SERVER', 'localhost');
?>
